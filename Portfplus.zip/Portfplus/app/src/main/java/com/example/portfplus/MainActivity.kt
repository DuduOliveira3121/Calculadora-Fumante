package com.example.portfplus

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.portfplus.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btIrParaPortf.setOnClickListener {
            val intent = Intent(this, Portifolio::class.java)
            startActivity(intent)
        }


        binding.btCalcular.setOnClickListener {
            val CigarrosPorDia = binding.editCigarrosPorDia.text.toString()
            val Anos = binding.editAnos.text.toString()

            if (CigarrosPorDia.isEmpty() || Anos.isEmpty()) {
                binding.txtResultado.setText("Preencha os campos!")
                binding.txtResultado.setTextColor(getColor(R.color.cor_04))
            } else {
                calcularcigarros(CigarrosPorDia = CigarrosPorDia.toFloat(), Anos = Anos.toFloat())
            }
        }
    }

        private fun calcularcigarros(CigarrosPorDia: Float, Anos: Float) {

            val totalCigarros = (Anos * 365.0) * CigarrosPorDia
            val minPerdidos = totalCigarros * 10.0
            val diasPerdidos = minPerdidos / (24.0 * 60.0)
            val anosPerdidos = diasPerdidos / 365.0

            // Formatar e mostrar o resultado na tela
            val textoResultado = "Você perdeu aproximadamente ${String.format("%.1f", diasPerdidos)} dias de vida.\n" +
                    "Isso equivale a mais ou menos \n${String.format("%.1f", anosPerdidos)} anos."

            binding.txtResultado.text = textoResultado
            binding.txtResultado.setTextColor(getColor(R.color.black)) // EDUARDO cria essa cor no seu arquivo colors.xml.
        }
    }